# Marina Golubeva
----------------
### Contact information
- tel: **+7-961-07-333-65**
- e-mail: **golubeva.webmaster@gmail.com**
- github: **@golubeva-webmaster**
- Skype: **marigolu2**
- Discord: **Marina(@golubeva-webmaster)**

### About myself
My aim is to become a specialist in **Front-End Development**

##### Hardskills
- PHP
- bitrix API
- JavaScript
- HTML
- CSS/SASS
- Git/github
- BEM metodology

##### Softskills
1. purposefulness
2. curiosity
3. ability to quickly learn new things
4. ability to perceive a large amount of information
5. ability to independently plan my working hours and follow this plan

### Example of code
- [Portfolio](https://github.com/golubeva-webmaster/Portfolio)
- [Examples of code](https://github.com/golubeva-webmaster/working_practices_on_bitrix/blob/main/README.md)
- [Codewars](https://www.codewars.com/users/golubeva-webmaster)

### Work experience

### Education / training courses
I have been working as a programmer since 2000. 
1. Volgograd State University (Faculty of Mathematics and Informatics)
2. JavaScript on code-basics.com
3. JavaScript on learn.javascript.ru
4. JavaScript on developer.mozilla.org
5. [RS Scool JavaScript Front-end 2021Q1 sertificate](https://app.rs.school/certificate/qm2m5pdc)
6. Video lessons **Javascript** on youtube

### English language
Proficiency level - **A2**